# 快速开始指南

## 1. 安装依赖

```bash
pip install -r requirements.txt
```


## 2. 配置训练参数

编辑 `train.sh` 文件，设置：
- `DATA_FILE`: 数据文件路径
- `OUTPUT_DIR`: 输出目录
- `PRETRAINED_MODEL`: 预训练模型路径
- 其他超参数

## 3. 开始训练

```bash
./train.sh
```

或者直接运行：

```bash
deepspeed --num_gpus=8 src/train.py \
    --deepspeed_config cfg/ds_config_bf16_stage2.json \
    --data_file data/your_data.pkl \
    --pretrained_model /path/to/model \
    --out_dir output/exp1 \
    --lora_r 16 \
    --use_pairwise \
    --batch_size 32 \
    --epochs 10
```

## 4. 监控训练

```bash
# 查看训练日志
tail -f output/exp1/train_log.txt

# 查看评估日志
tail -f output/exp1/eval_log.txt
```

## 5. 评估模型

```bash
deepspeed --num_gpus=8 src/train.py \
    --deepspeed_config cfg/ds_config_bf16_stage2.json \
    --data_file data/your_data.pkl \
    --pretrained_model /path/to/model \
    --out_dir output/exp1 \
    --lora_r 16 \
    --do_eval \
    --ii 10240
```

详细文档请参阅 [README.md](README.md)
