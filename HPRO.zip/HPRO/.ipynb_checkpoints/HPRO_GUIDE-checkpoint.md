# HPRO 使用指南

## 什么是 HPRO？

HPRO (Hierarchical Preference Ranking Optimization) 是一种基于销售漏斗层级的偏好排序优化方法，通过构建不同强度的偏好对来充分利用过程数据中的监督信号。

## 核心思想

传统的二分类方法将所有未转化样本视为相同的负样本，忽略了过程信息。HPRO通过销售漏斗定义样本层级，构建多层次的偏好关系：

```
Lock-in (订单锁定) > Test Drive (试驾) > Call (电话) > Defeat (战败)
     ↑                     ↑                 ↑              ↑
  Stage 3              Stage 2           Stage 1        Stage 0
```

## 偏好对类型

### 1. Global Dominance (margin=1.0)
最强的偏好信号：Lock-in vs Defeat

```python
# 代码中的实现
lock_mask = (funnel_stages == 3)
defeat_mask = (funnel_stages == 0)
diff = s_lock - s_defeat
loss_global = -log(sigmoid(diff - 1.0))
```

### 2. Key Action (margin=0.5)
关键中间指标：Test Drive vs No Drive

```python
drive_mask = (funnel_stages == 2)
no_drive_mask = (funnel_stages == 1)
diff = s_drive - s_no_drive
loss_key = -log(sigmoid(diff - 0.5))
```

### 3. Soft Signal (margin=0.1)
密集但弱的行为信号：Long Call vs Short Call

```python
long_call_mask = (funnel_stages >= 1) & (labels == 1)
short_call_mask = (funnel_stages >= 1) & (labels == 0)
diff = s_long - s_short
loss_soft = -log(sigmoid(diff - 0.1))
```

## 数据准备

### 选项1: 使用现有数据（推荐）
如果您的数据没有漏斗阶段信息，代码会自动回退到标准的pairwise loss：

```python
# 不需要额外处理，直接使用
python src/train.py --use_hpro ...
# 会使用label信息构建简单的偏好对
```

### 选项2: 添加漏斗阶段信息（可选）
如果您有漏斗阶段数据，可以在`dataset.py`中添加：

```python
# 在 MyDataset 或 MyDatasetWithDataAug 中添加
def __getitem__(self, index):
    # ... 现有代码 ...

    # 添加漏斗阶段（根据您的业务逻辑）
    if hasattr(self, 'funnel_stage'):
        funnel_stage = self.funnel_stage[index]
        return (input_ids, attention_mask, label, label_str, funnel_stage)
    else:
        return (input_ids, attention_mask, label, label_str)
```

漏斗阶段编码建议：
- `0`: 战败/流失客户
- `1`: 仅电话接通
- `2`: 完成试驾
- `3`: 订单锁定

## 使用示例

### 基础使用（无漏斗数据）

```bash
deepspeed --num_gpus=8 src/train.py \
    --deepspeed_config cfg/ds_config_bf16_stage2.json \
    --data_file data/train_data.pkl \
    --pretrained_model /path/to/Qwen1.5-1.8B \
    --out_dir output/hpro_basic \
    --lora_r 16 \
    --use_hpro \
    --batch_size 32 \
    --epochs 10
```

### 高级使用（自定义margins）

```bash
deepspeed --num_gpus=8 src/train.py \
    --deepspeed_config cfg/ds_config_bf16_stage2.json \
    --data_file data/train_data.pkl \
    --pretrained_model /path/to/Qwen1.5-1.8B \
    --out_dir output/hpro_custom \
    --lora_r 16 \
    --use_hpro \
    --hpro_margin_global 2.0 \    # 增大全局优势margin
    --hpro_margin_key 0.8 \        # 增大关键动作margin
    --hpro_margin_soft 0.2 \       # 增大软信号margin
    --batch_size 32 \
    --epochs 10
```

## 参数调优建议

### Margin 设置原则

1. **全局优势 margin (global)**: 设置最大
   - 默认: 1.0
   - 建议范围: 0.5 - 2.0
   - 作用: 确保转化客户与流失客户之间有明显分隔

2. **关键动作 margin (key)**: 设置中等
   - 默认: 0.5
   - 建议范围: 0.3 - 1.0
   - 作用: 区分关键行为（如试驾）的重要性

3. **软信号 margin (soft)**: 设置最小
   - 默认: 0.1
   - 建议范围: 0.05 - 0.3
   - 作用: 利用密集的弱信号进行细粒度排序

### 调优策略

1. **从默认值开始**
   ```bash
   --use_hpro  # 使用默认 margins
   ```

2. **观察训练日志**
   ```
   pw_loss 的值应该稳定下降
   如果 pw_loss 过大或不收敛，尝试减小 margins
   ```

3. **根据业务调整**
   - 如果关键动作（试驾）很重要，增大 `hpro_margin_key`
   - 如果转化信号明确，增大 `hpro_margin_global`

## 与标准方法对比

### 标准 Pairwise Loss (BPR)

```bash
--use_pairwise
```
- 只区分 positive vs negative
- 所有 negative 样本被同等对待
- 忽略过程信息

### HPRO

```bash
--use_hpro
```
- 区分多层次的偏好关系
- 充分利用漏斗层级信息
- 密集的监督信号

## 预期效果

启用 HPRO 后，您应该看到：

1. **更好的排序性能**
   - Top-K 指标提升（P@100, R@100等）
   - AUC 提升

2. **更合理的分数分布**
   - 高价值客户得分显著高于低价值客户
   - 分数与漏斗阶段呈现明显相关性

3. **训练更稳定**
   - 密集的监督信号使训练更平滑
   - 更少的过拟合风险

## 常见问题

### Q: 我的数据没有漏斗阶段信息，可以用HPRO吗？
A: 可以！代码会自动回退到基于label的简单偏好对，仍然比标准BPR有优势。

### Q: HPRO会影响现有训练吗？
A: 不会。不使用`--use_hpro`时，代码行为与原版本完全一致。

### Q: HPRO训练速度如何？
A: 与标准pairwise loss相比，计算开销略有增加（约10-15%），但性能提升通常值得。

### Q: 如何验证HPRO是否生效？
A: 查看训练日志中的 `pw_loss`，HPRO启用时会显示分层的偏好损失计算。

## 论文引用

如果HPRO对您的研究有帮助，请引用：

```bibtex
@article{hpro2024,
  title={HPRO: Hierarchical Preference Ranking Optimization for LLM-based Long-Chain Sales Lead Scoring},
  author={Your Name},
  year={2024}
}
```
