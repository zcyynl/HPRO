# 更新日志

## v2.0 - HPRO 版本

### 新增功能

#### 1. HPRO (Hierarchical Preference Ranking Optimization)
- **三层偏好对构建**:
  - Global Dominance: Lock-in vs Defeat (margin=1.0)
  - Key Action: Test Drive vs No Drive (margin=0.5)
  - Soft Signal: Long Call vs Short Call (margin=0.1)

- **Margin-Aware Bradley-Terry Loss**:
  ```python
  P(x_w > x_l | m) = sigmoid(s(x_w) - s(x_l) - m)
  ```

- **自动回退机制**: 无漏斗数据时自动使用标准pairwise loss

#### 2. 新增参数
```bash
--use_hpro               # 启用HPRO
--hpro_margin_global     # 全局优势margin (默认1.0)
--hpro_margin_key        # 关键动作margin (默认0.5)
--hpro_margin_soft       # 软信号margin (默认0.1)
```

#### 3. 数据兼容性增强
- 支持4元组格式: `(input_ids, attention_mask, label, label_str)`
- 支持5元组格式: `(input_ids, attention_mask, label, label_str, funnel_stages)`
- 自动检测并适配数据格式

### 向后兼容
- ✅ 不使用 `--use_hpro` 时，代码行为与v1.0完全一致
- ✅ 现有训练脚本无需修改即可运行
- ✅ 所有原有参数保持不变

### 文档更新
- 新增 `HPRO_GUIDE.md`: HPRO详细使用指南
- 更新 `README.md`: 添加HPRO使用示例
- 更新 `train.sh`: 添加HPRO训练选项

### 代码改进
- 重构 `LanguageModelWithLinear.__init__()`: 添加HPRO参数
- 新增 `hpro_loss_fn()`: 实现层级化偏好排序损失
- 增强 `forward()`: 支持可选的funnel_stages输入
- 改进 `train()` 和 `evaluate()`: 自动处理不同数据格式

---

## v1.0 - 基础版本

### 核心功能
- LoRA/PiSSA 参数高效微调
- 三头架构: Semantic + Pointwise + Pairwise
- 标准 Pairwise Ranking Loss (BPR)
- 平衡批次采样
- 数据增强
- 分布式训练支持

### 损失函数
- BCE Loss (Pointwise)
- CE Loss (Semantic)
- Pairwise Loss (BPR/Hinge)
- Contrastive Loss (可选)
